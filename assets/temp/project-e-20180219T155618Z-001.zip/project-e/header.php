<header><div class="header-container header">
            <a class="navbar-brand logo" href="#"> <img class="logo" src="assets/images/egalitarian_logo_long.png"/> </a>
            <a href="#email-form">
                <button class="button header-btn2"> Contribute </button>
                <button class="button header-btn1"> Whats Your Idea? </button>
            </a>
            <div class="header-menu">
                <a class="navbar-item" href="#team">Inequality</a>
                <a class="navbar-item" href="#pricing">Ideas</a>
                <a class="navbar-item" href="#pricing">Projects</a>
                <a class="navbar-item" href="#features">About Us</a>
            </div>
        </div>
</header>