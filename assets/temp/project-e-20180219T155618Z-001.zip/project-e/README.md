{\rtf1\ansi\ansicpg1252\cocoartf1504\cocoasubrtf810
{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;\f1\fnil\fcharset0 Menlo-Bold;}
{\colortbl;\red255\green255\blue255;\red198\green124\blue72;\red0\green61\blue204;\red0\green68\blue254;
\red255\green39\blue18;\red0\green68\blue254;\red255\green255\blue255;}
{\*\expandedcolortbl;;\csgenericrgb\c77800\c48800\c28400;\csgenericrgb\c0\c23922\c80000;\csgenericrgb\c0\c26667\c99608;
\csgenericrgb\c100000\c15294\c7059;\csgenericrgb\c0\c26667\c99608;\csgenericrgb\c100000\c100000\c100000;}
\paperw11900\paperh16840\margl1440\margr1440\vieww14140\viewh14260\viewkind0
\deftab543
\pard\tx543\pardeftab543\pardirnatural\partightenfactor0

\f0\fs28 \cf2 \CocoaLigature0 \
# \'93Nova\'94 Theme Landing Page (HTML)\
\cf3 \
Nova is a responsive HTML template, built on top of Bootstrap 4. \
\
\cf4 It is a freebie by\cf3  
\f1\b \cf5 Webscope \cf4 -\cf5  
\f0\b0 \cf6 https://webscopeapp.com : \
\
A  super easy and cool Client feedback tool. \cf7 \
\cf2 \
## License\
\cf4 \
Use it freely but please do not republish, distribute or sell "as-is". Please credit the designer and developer when you use it in your project.\cf3 \
\cf2 \
## Misc\cf7 \
\
\cf4 Check Out- https://webscopeapp.com\
\
Follow us on Twitter: {\field{\*\fldinst{HYPERLINK "https://twitter.com/webscopeapp"}}{\fldrslt https://twitter.com/webscopeapp}}\
\
Follow us on Facebook: {\field{\*\fldinst{HYPERLINK "https://www.facebook.com/webscopeapp/"}}{\fldrslt https://www.facebook.com/webscopeapp/}}\
}