<html>

<?php include 'head.php';?>

<body>
    
<!--<div id="sidecarNav">
      <div id="mobileNavWrapper" class="nav-wrapper" data-content-field="navigation-mobileNav">
  <nav id="mobileNavigation">
        <div class="external">
          <a href="">
            Inequality
          </a>
        </div>
          <div class="collection">
            <a href="">
              Our Mission
            </a>
          </div>
          <div class="collection">
            <a href="">
              Projects
            </a>
          </div>
          <div class="collection">
            <a href="">
              BECOME AN EQUAL
            </a>
          </div>
        <div class="external">
          <a href="">
            CONTRIBUTE
          </a>
      </div>
  </nav>
</div>
    </div>
    
    <div class="mobile-nav-toggle" id="yui_3_17_2_1_1499401181614_268">
            <div class="top-bar"></div>
            <div class="middle-bar"></div>
            <div class="bottom-bar" id="yui_3_17_2_1_1499401181614_272"></div>
          </div>
    -->
<!-- Navigation
    ================================================== -->
<div class="front-section-background">
    <div>
        <img class="strips" src="assets/images/top-background.png">
    </div>
        <?php include 'header.php';?>
        <!--navigation-->


        <!-- Hero-Section
          ================================================== -->

        <div class="front-section row">
            <div class="front-section-right col-sm-6 col-sm-6">
                <p class="header-headline bold"> Inequality = Inhumanity <br></p>
                <p class="header-running-text light"> We believe equality leads to freedom, love and inspiration. <br>You have an idea to support equality? Tell us, we will support you make it a real project. </p>
                <p class="front-section-btn-container">
                <a href="#email-form">
                    <button class="button front-section-btn"> Whats Your Idea? </button>
                </a>
                </p>
            </div>
        </div><!--front-section-->


</div><!--front-section-background-->

<!-- Problems
  ================================================== -->
<div id="problems" class="problems-background">

    
    <h2 class="problems-section-header1 light text-center"> We were once Equal. Then something changed. </h2>
    <h4 class=" problems-section-sub1 text-center light"> For centuries, we've been implanted with ideas of inequality. Ideas that are deeply rooted in our daily lives and have become practices.</h4>

    
    <div class="problem-definition-section row">
        <div class="col-sm-4">
            <div class="problems-sec-icon">
                <img class="problems-sec-img" src="assets/images/problem_sec_womenequality.png" alt=""/>
            </div>
            <p class="problems-sec-def">Women represent the weaker gender,<br> not equal</p>         
        </div>
        <div class="col-sm-4">
            <div class="problems-sec-icon">
                <img class="problems-sec-img" src="assets/images/problem_sec_financialequality.png" alt=""/>
            </div>
            <p class="problems-sec-def">Low profile workers are paid less, <br>not equal</p>             
        </div>
        <div class="col-sm-4">
            <div class="problems-sec-icon">
                <img class="problems-sec-img" src="assets/images/problem_sec_ageequality.png" alt=""/>
            </div>
            <p class="problems-sec-def">Old people are treated different, <br>not equal</p>     
        </div>
    </div>
    
    
    
    <h2 class="problems-section-header2 light text-center"> But we are Humans. <br>We can Change. </h2>
    <h4 class=" problems-section-sub2 text-center light"> Now is the time to change. Forget our past. Change our present. Change our future. Change for centuries to come. <br><br>Every big change needs a small start and an <span style="color:var(--egalitarian-yellow); font-weight:bold;">idea</span> to begin.<br><br> Let's convert your's into a real project.</h4>


    <div class="problem-sec-btn-cntr ">
        <button class="button problem-sec-btn"> Whats Your Idea? </button>
    </div>
    
</div><!--problems-background-->

<!-- Projects
  ================================================== -->

<div id="features" class="features-section">

    <div class="features-container row">

        <h2 class="features-headline light">Projects</h2>

        <div class="col-sm-4 feature">

            <div class="feature-icon feature-no-display">
                <img class="feature-img" src="assets/images/responsive.svg">
            </div>
            <h5 class="feature-head-text feature-no-display"> FULLY RESPONSIVE </h5>
            <p class="feature-subtext light feature-no-display"> Looks amazing on any
                device: smartphone, tablet, laptop and desktop.</p>
        </div>

        <div class="col-sm-4 feature">
            <div class="feature-icon feature-no-display feature-display-mid">
                <img class="feature-img" src="assets/images/customizable.svg">
            </div>
            <h5 class="feature-head-text feature-no-display feature-display-mid"> CUSTOMIZABLE </h5>
            <p class="feature-subtext light feature-no-display feature-display-mid"> Change the colors, pictures or any
                of the sections
                to suit your needs.</p>
        </div>

        <div class="col-sm-4 feature">
            <div class="feature-icon feature-no-display feature-display-last">
                <img class="bullet-img" src="assets/images/design.svg">
            </div>
            <h5 class="feature-head-text feature-no-display feature-display-last"> SLICK AND BEAUTIFUL DESIGN </h5>
            <p class="feature-subtext light feature-no-display feature-display-last"> Trendy and fresh design, fits any
                website.</p>
        </div>
    </div> <!--projects-container-->
</div> <!--projects-section-->

<!-- Logos
  ================================================== -->

<div class="logos-section">
    <img class="logos" src="assets/images/logos.png"/>
</div><!--logos-section-->

<!-- White-Section
  ================================================== -->

<div class="white-section row">

    <div class="imac col-sm-6">
        <img class="imac-screen img-responsive" src="assets/images/imac.png">
    </div>
    <!--imac-->

    <div class="col-sm-6">

        <div class="white-section-text">

            <h2 class="imac-section-header light">SIMPLE AND BEAUTIFUL</h2>

            <div class="imac-section-desc">

            <span>  Use Nova theme for your next web project.
                It is completely customizable so you can change any of the sections to fit your needs.
                Nova Theme is Free for any kind of use, personal and commercial. Have fun and good luck!</span>
            </div>
        </div>
    </div>
</div><!--white-section-text-section--->




<!-- Team
  ================================================== -->

<div id="team" class="team">
    <h2 class="team-section-header light text-center">THE TEAM</h2>

    <div class="team-container row">


        <div class="col-sm-4 team-member">
            <img src="assets/images/cto.png">
            <div class="team-member-text">
                <h4 class="team-member-position light">CTO</h4>
                <h5 class="bold">Johnny B Good</h5>
                <p class="light">The brains behind the whole operation</p>
                <a href="http://www.twitter.com"><img class="team-social-icon" src="assets/images/team-twitter.svg"></a>
                <a href="http://www.facebook.com"><img class="team-social-icon"
                                                       src="assets/images/team-facebook.svg"></a>
                <a href="https://plus.google.com/"><img class="team-social-icon"
                                                        src="assets/images/team-google.svg"></a>
            </div>
        </div>

        <div class="col-sm-4 team-member">
            <img src="assets/images/ceo.png">
            <div class="team-member-text">
                <h4 class="team-member-position light">CEO</h4>
                <h5 class="bold">Roll Over Beethoven</h5>
                <p class="light">The one that puts it all together </p>
                <a href="http://www.twitter.com"><img class="team-social-icon" src="assets/images/team-twitter.svg"></a>
                <a href="http://www.facebook.com"><img class="team-social-icon"
                                                       src="assets/images/team-facebook.svg"></a>
                <a href="https://plus.google.com/"><img class="team-social-icon"
                                                        src="assets/images/team-google.svg"></a>
            </div>
        </div>

        <div class="col-sm-4 team-member">
            <img src="assets/images/cfo.png">
            <div class="team-member-text">
                <h4 class="team-member-position light">CFO</h4>
                <h5 class="bold">Chuck Berry</h5>
                <p class="light">The guy with his hand on the wallet</p>
                <a href="http://www.twitter.com"><img class="team-social-icon" src="assets/images/team-twitter.svg"></a>
                <a href="http://www.facebook.com"><img class="team-social-icon"
                                                       src="assets/images/team-facebook.svg"></a>
                <a href="https://plus.google.com/"><img class="team-social-icon"
                                                        src="assets/images/team-google.svg"></a>
            </div>

        </div>
        <! -- .row -->

    </div> <!--team-container--->

</div> <!--team-section--->



<!-- Footer
  ================================================== -->
<?php include 'footer.php';?>
    
<!--footer-->

<script src="https://code.jquery.com/jquery-3.2.1.min.js"
        integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
        crossorigin="anonymous"></script>

<script src="assets/js/script.js"></script>

</body>

</html>